This is a free asset that can be used in non-commercial and commercial purpose.
You may copy, modify or share this asset as you see fit, 
however you may not credit yourself as the creator of this asset or modify the asset for the purpose of distribution. 
Credits appreciated.

The package contains 54 crosshaires in two different styles, a unitypackage and the project file (for aseprite).